import { useEffect, useState } from 'react';
import { getTunes } from '../services/tuneService';
import AudioPlayer from '../components/AudioPlayer';

interface Tune {
  id: string;
  title: string;
  artist: string;
  genre: string;
  price: number;
  previewUrl: string;
}

export default function TuneMarket() {
  const [tunes, setTunes] = useState<Tune[]>([]);
  const [selectedTune, setSelectedTune] = useState<Tune | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTunes = async () => {
      try {
        const data = await getTunes();
        setTunes(data);
        setLoading(false);
      } catch (error) {
        console.error('Failed to load tunes:', error);
      }
    };
    
    fetchTunes();
  }, []);

  if (loading) return <div>Loading tunes...</div>;

  return (
    <div className="max-w-6xl mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">U-Tune Marketplace</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tunes.map(tune => (
          <div 
            key={tune.id} 
            className={`border rounded-lg p-4 cursor-pointer transition-all ${
              selectedTune?.id === tune.id 
                ? 'border-blue-500 shadow-lg' 
                : 'border-gray-200 hover:shadow-md'
            }`}
            onClick={() => setSelectedTune(tune)}
          >
            <h3 className="font-bold text-lg">{tune.title}</h3>
            <p className="text-gray-600">{tune.artist}</p>
            <div className="mt-2 flex justify-between items-center">
              <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                {tune.genre}
              </span>
              <span className="font-bold">₦{tune.price.toFixed(2)}</span>
            </div>
          </div>
        ))}
      </div>
      
      {selectedTune && (
        <div className="mt-8 p-6 bg-gray-50 rounded-lg">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-2xl font-bold">{selectedTune.title}</h2>
              <p className="text-gray-700">{selectedTune.artist}</p>
            </div>
            <button 
              className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
              onClick={() => activateTune(selectedTune.id)}
            >
              Activate for ₦50
            </button>
          </div>
          
          <div className="mt-4">
            <AudioPlayer src={selectedTune.previewUrl} />
          </div>
        </div>
      )}
    </div>
  );
}