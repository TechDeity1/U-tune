import { useState } from 'react';
import { FirebaseAuth } from '../../services/firebase';

export default function PhoneVerification() {
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [step, setStep] = useState<'input' | 'verify'>('input');
  const [loading, setLoading] = useState(false);
  const [recaptcha, setRecaptcha] = useState<any>(null);

  const initRecaptcha = async () => {
    if (!recaptcha) {
      const { RecaptchaVerifier } = await import('firebase/auth');
      const verifier = new RecaptchaVerifier('recaptcha', {
        size: 'invisible',
      }, FirebaseAuth);
      setRecaptcha(verifier);
    }
    return recaptcha;
  };

  const sendCode = async () => {
    setLoading(true);
    try {
      const verifier = await initRecaptcha();
      await signInWithPhoneNumber(FirebaseAuth, `+234${phone}`, verifier);
      setStep('verify');
    } catch (error) {
      console.error('Error sending code:', error);
    }
    setLoading(false);
  };

  const verifyCode = async () => {
    setLoading(true);
    try {
      const confirmationResult = window.confirmationResult;
      await confirmationResult.confirm(code);
      // Proceed to dashboard
    } catch (error) {
      console.error('Invalid code:', error);
    }
    setLoading(false);
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-lg">
      <h1 className="text-2xl font-bold mb-6">Verify Your Phone</h1>
      
      {step === 'input' ? (
        <>
          <div className="mb-4">
            <label className="block mb-2">Phone Number</label>
            <div className="flex">
              <div className="bg-gray-100 p-2 rounded-l border border-gray-300">+234</div>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                className="flex-1 p-2 border border-gray-300 rounded-r"
                placeholder="8001234567"
              />
            </div>
          </div>
          <button
            onClick={sendCode}
            disabled={loading || phone.length < 10}
            className="w-full bg-blue-600 text-white py-2 rounded disabled:bg-gray-400"
          >
            {loading ? 'Sending...' : 'Send Verification Code'}
          </button>
        </>
      ) : (
        <>
          <div className="mb-4">
            <label className="block mb-2">Verification Code</label>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded"
              placeholder="Enter 6-digit code"
            />
          </div>
          <button
            onClick={verifyCode}
            disabled={loading || code.length < 6}
            className="w-full bg-blue-600 text-white py-2 rounded disabled:bg-gray-400"
          >
            {loading ? 'Verifying...' : 'Verify Code'}
          </button>
        </>
      )}
      
      <div id="recaptcha" className="hidden"></div>
    </div>
  );
}