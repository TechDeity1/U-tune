// types.ts

// Example of an interface
export interface User {
    id: number;
    username: string;
    email: string;
    createdAt: Date;
}

// Example of a type alias
export type UserRole = 'admin' | 'user' | 'guest';

// Example of an enum
export enum Status {
    Active = 'active',
    Inactive = 'inactive',
    Pending = 'pending',
}

// A complex type example
export interface Post {
    id: number;
    title: string;
    content: string;
    author: User; // Referencing the User interface
    tags?: string[]; // Optional property
}

// Example for a function type
export type FetchUserFunction = (id: number) => Promise<User>;