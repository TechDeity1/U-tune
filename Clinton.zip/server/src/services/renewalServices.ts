import cron from 'node-cron';
import Tune from '../models/Tune';
import User from '../models/User';
import { activateTune } from '../controllers/tuneController';

// Run daily at 2 AM
cron.schedule('0 2 * * *', async () => {
  try {
    // Find tunes expiring in 3 days
    const expiringDate = new Date();
    expiringDate.setDate(expiringDate.getDate() + 3);
    
    const expiringTunes = await Tune.find({
      expiresAt: { $lte: expiringDate },
      renewedAt: { $exists: false }
    }).populate('userId');
    
    for (const tune of expiringTunes) {
      const user = tune.userId;
      
      // Check balance and renew
      if (user.balance >= 50) {
        user.balance -= 50;
        await user.save();
        
        tune.renewedAt = new Date();
        tune.expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
        await tune.save();
        
        // Notify user
        sendNotification(user.phone, `Your tune was renewed! New expiry: ${tune.expiresAt.toDateString()}`);
      } else {
        sendNotification(user.phone, 'Insufficient balance to renew your tune');
      }
    }
  } catch (error) {
    console.error('Renewal service error:', error);
  }
});

function sendNotification(phone: string, message: string) {
  // Implementation using Africa's Talking SMS
}