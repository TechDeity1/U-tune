import express from 'express';
import { 
  activateTune, 
  copyFriendTune,
  listTunes,
  renewTune
} from '../controllers/tuneController';
import authMiddleware from '../middleware/auth';

const router = express.Router();

// Protected routes
router.use(authMiddleware);

router.post('/activate', activateTune);
router.post('/copy', copyFriendTune);
router.get('/', listTunes);
router.post('/:id/renew', renewTune);

export default router;