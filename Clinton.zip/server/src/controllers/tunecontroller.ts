import { Request, Response } from 'express';
import AfricasTalking from 'africastalking';
import Tune from '../models/Tune';
import User from '../models/User';

const africastalking = AfricasTalking({
  apiKey: process.env.AFRICAS_TALKING_API_KEY!,
  username: 'u-tune'
});

export const activateTune = async (req: Request, res: Response) => {
  try {
    const { tuneId, phone } = req.body;
    const userId = req.user.id; // From auth middleware

    // 1. Verify user balance
    const user = await User.findById(userId);
    if (user!.balance < 50) {
      return res.status(400).json({ error: 'Insufficient balance' });
    }

    // 2. Deduct balance
    user!.balance -= 50;
    await user!.save();

    // 3. Activate with carrier
    await africastalking.VOICE.call({
      callFrom: 'U-TUNE',
      callTo: [`+234${phone}`],
      // Additional RBT activation parameters
    });

    // 4. Save activation record
    const activation = new Tune({
      userId,
      tuneId,
      activatedAt: new Date(),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days
    });
    await activation.save();

    res.status(200).json({ message: 'Tune activated successfully' });
  } catch (error) {
    console.error('Activation error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

export const copyFriendTune = async (req: Request, res: Response) => {
  try {
    const { friendPhone } = req.body;
    
    // 1. Detect friend's tune (simulated)
    const friendTune = await detectFriendsTune(friendPhone);
    
    // 2. Activate for current user
    req.body.tuneId = friendTune;
    await activateTune(req, res);
  } catch (error) {
    console.error('Copy error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

async function detectFriendsTune(phone: string): Promise<string> {
  // In a real implementation, this would query carrier APIs
  return 'TUNE_' + phone.substring(phone.length - 4);
}