import mongoose, { Document } from 'mongoose';

interface IUser extends Document {
  phone: string;
  balance: number;
  activeTune?: string;
  createdAt: Date;
}

const UserSchema = new mongoose.Schema({
  phone: { 
    type: String, 
    required: true, 
    unique: true,
    match: /^[0-9]{10}$/ // Nigerian phone format
  },
  balance: { 
    type: Number, 
    default: 0,
    min: 0
  },
  activeTune: { type: mongoose.Schema.Types.ObjectId, ref: 'Tune' },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model<IUser>('User', UserSchema);