import mongoose, { Document } from 'mongoose';

interface ITune extends Document {
  userId: mongoose.Types.ObjectId;
  tuneId: string;
  activatedAt: Date;
  expiresAt: Date;
  renewedAt?: Date;
}

const TuneSchema = new mongoose.Schema({
  userId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  tuneId: { type: String, required: true },
  activatedAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, required: true },
  renewedAt: Date
});

// Index for expiration checks
TuneSchema.index({ expiresAt: 1 });

export default mongoose.model<ITune>('Tune', TuneSchema);